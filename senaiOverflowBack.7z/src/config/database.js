module.exports = {
    host: "localhost",
    username: "root",
    password: "bcd127",
    database: "dbsenaioverflow",
    dialect: "mysql",
    define: {
        timestamp: true,
        underscored: true
    }
}