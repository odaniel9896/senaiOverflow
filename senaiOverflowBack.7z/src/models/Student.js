const { Model, DataTypes } = require("sequelize");

class Student extends Model {
    /**
     * aqui configuramos os campos da tabela
     * os campos automáticos não precisam ser declarados
     */
    static init(sequelize) {
        super.init(
            {
                ra: DataTypes.STRING,
                name: DataTypes.STRING,
                email: DataTypes.STRING,
                password: DataTypes.STRING
            },
            {
                sequelize,
            }
        )
    }

    /**
     * aqui configuramos os relacionamentos 
     */
    static associate(models) {
        this.hasMany(models.Answer)
        this.hasMany(models.Question);
    }
}

module.exports = Student;